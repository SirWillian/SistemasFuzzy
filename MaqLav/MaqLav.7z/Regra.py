class Regra(object):
    def __init__(self, antecedentes, consequente):
        self.antecedentes=antecedentes
        self.consequente=consequente
